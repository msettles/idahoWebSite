#! /bin/bash
pdflatex _1mattDissertation
pdflatex _1mattDissertation
bibtex _1mattDissertation
pdflatex _1mattDissertation
pdflatex _1mattDissertation
rm -rf *.aux *.dvi *.lof *.lot *.out *.blg *.toc *.bbl
mv _1mattDissertation.pdf mattDissertation.pdf
open mattDissertation.pdf 
