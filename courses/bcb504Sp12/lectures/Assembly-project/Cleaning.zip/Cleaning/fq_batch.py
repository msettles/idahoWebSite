!/bin/env python
#This python script requires Biopython 1.51 or later
# Description: Batches an interleaved file into a number of files
#
# Author: Matt Settles <msettles@uidaho.edu>
# Last Edited: Feb 12, 2012
#
# Assumptions:
# Paired end data is interleaved

from optparse import OptionParser
from Bio import SeqIO
import itertools
import sys

usage = "usage: %prog [options] file_interleaved.fastq output_basename"
parser = OptionParser(usage=usage)
parser.add_option("-f", "--format",
                  action="store", type="string", dest="format", default="fastq",
                  help="input file format (fastq,fastq-illumina, or fasta)")
parser.add_option("-b", "--batch_size",
                  action="store", type="int", dest="batch_size", default=1000000,
                  help="the number of paired end reads per batch")


(options, args) = parser.parse_args()

if len(args) != 2:
    parser.error("incorrect number of arguments")

format = options.format
batch_size = options.batch_size

file_in = args[0]
out_base = args[1]

record_iter = SeqIO.parse(open(file_in,"rU"), format)

#taken from
## http://biopython.org/wiki/Split_large_file
def batch_iterator(iterator, batch_size) :
    """Returns lists of length batch_size.
    
    This can be used on any iterator, for example to batch up
    SeqRecord objects from Bio.SeqIO.parse(...), or to batch
    Alignment objects from Bio.AlignIO.parse(...), or simply
    lines from a file handle.
    
    This is a generator function, and it returns lists of the
    entries from the supplied iterator.  Each list will have
    batch_size entries, although the final list may be shorter.
    """
    entry = True #Make sure we loop once
    while entry :
        batch = []
        while len(batch) < batch_size :
            try :
                entry = iterator.next()
            except StopIteration :
                entry = None
            if entry is None :
                #End of file
                break
            batch.append(entry)
        if batch :
            yield batch
            
for i, batch in enumerate(batch_iterator(record_iter, batch_size*2)) : # times 2 for paired end
    filename = out_base + "_" + str(i+1) + "." + format
    handle = open(filename, "w")
    count = SeqIO.write(batch, handle, format)
    handle.close()
    print "Wrote %i records to %s" % (count, filename)


