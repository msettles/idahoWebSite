#!/bin/env python
#This python script requires Biopython 1.51 or later
# Description: removes any read pair with an N
#
# Author: Matt Settles <msettles@uidaho.edu>
# Last Edited: Feb 12, 2012
#
# Assumptions:
# Paired end data is interleaved

import sys
from Bio import SeqIO

iter = SeqIO.parse(open(sys.argv[1]), "fastq")
try:
	while 1:
		rec1 = iter.next()
		rec2 = iter.next()

		if "N" in rec1 or "N" in rec2:
			continue

		SeqIO.write([rec1, rec2], sys.stdout, "fastq")
except StopIteration, e:
	pass

