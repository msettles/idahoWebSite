cd /mnt/home/uirig/data/Gustavo_Analysis/SFF

# combine the SFF files
SFFfile -o combined.SFF MBE.SFF RH.SFF

# extract fasta, fasta.qual and fastq format using SFF_extract and parse the resulting xml file
SFF_extract combined.SFF 
SFF_extract -Q combined.SFF 
parseSFF_XML.pl -i combined.xml

## START Rdev
options(width=120)
options("stringsAsFactors" = FALSE)
library(ShortRead)

fq <- readFastq("combined.fastq")

ReadData <- data.frame(Acc=as.character(id(fq)),
                      Run=as.character(subseq(id(fq),1,7)),
                      Region=as.character(subseq(id(fq),8,9)),
                      Loc=as.character(subseq(id(fq),10,14)),
                      RawLength=width(fq))



clip <- read.table("combined.xml.txt",sep="\t",as.is=T)
colnames(clip) <- c("Acc","LC","RC")
clip <- clip[match(ReadData$Acc,clip$Acc),]
clip$ReadLen <- width(sread(fq))
clip$LC[which(is.na(clip$LC))] <- 1
clip$RC[which(is.na(clip$RC))] <- clip$ReadLen[which(is.na(clip$RC))]

ReadData$RocheLC <- clip$LC
ReadData$RocheRC <- clip$RC
ReadData$RocheLength <- clip$RC - clip$LC +1

ReadData$AdapterLC <- ReadData$RocheLC
ReadData$AdapterRC <- ReadData$RocheRC



#####################################################
#### Loop through looking for adaptors
## Read in Cross_Match Alignment of Adaptors and Primers
system("cp combined.fasta combined_orig.fasta")
system("sed -i 's/^tcag/----/g' combined.fasta")

system("cross_match combined.fasta ../screen.fa -minmatch 15 -minscore 14 -screen -tags > cross_match.out")
system("grep \"ALIGNMENT\" cross_match.out | replace ' C ' ' C_' --  > cm_alignment.out")
# copy back over the original file
system("mv combined_orig.fasta combined.fasta")

cm_out <- read.table("cm_alignment.out",as.is=TRUE)
cm_out$FC <- "F"
cm_out$FC[grep("^C_",cm_out$V10)] <- "C"
cm_out[cm_out$FC == "C",c("V11","V12","V13")] <- cm_out[cm_out$FC == "C",c("V13","V12","V11")]
colnames(cm_out) <- c("Alignment","score","perc_sub","perc_del","perc_ins","read_id",
    "read_start","read_end","read_remain","adapt","adapt_start","adapt_end","adapt_remain","FC")
cm_out$read_remain <- as.numeric(gsub("[()]","",cm_out$read_remain))
cm_out$adapt_remain <- as.numeric(gsub("[()]","",cm_out$adapt_remain))
cm_out$adapt_start <- as.numeric(cm_out$adapt_start)
cm_out$adapt_end <- as.numeric(cm_out$adapt_end)

cm_out$perc_sub <- round(cm_out$perc_sub *(cm_out$read_end - cm_out$read_start +1),digits=0)/100
cm_out$perc_del <- round(cm_out$perc_del *(cm_out$read_end - cm_out$read_start +1),digits=0)/100
cm_out$perc_ins <- round(cm_out$perc_ins *(cm_out$read_end - cm_out$read_start +1),digits=0)/100

cm_out$read_len <- width(sread(fq))[match(cm_out$read_id,clip$Acc)]
#############################################################
## 
ReadData$AdapterLC[match(cm_out$read_id[which(cm_out$FC == "F")],ReadData$Acc)] <- 
    pmax(ReadData$AdapterLC[match(cm_out$read_id[which(cm_out$FC == "F")],ReadData$Acc)],
    cm_out$read_end[which(cm_out$FC == "F")])

ReadData$AdapterRC[match(cm_out$read_id[which(cm_out$FC == "C")],ReadData$Acc)] <- 
    pmin(ReadData$AdapterRC[match(cm_out$read_id[which(cm_out$FC == "C")],ReadData$Acc)],
    cm_out$read_start[which(cm_out$FC == "C")])

## repeat above, until output tabled output no longer changes
table(ReadData$AdapterLC == ReadData$RocheLC)
table(ReadData$AdapterRC == ReadData$RocheRC)

ReadData$AdapterRC <- pmax(ReadData$AdapterRC,ReadData$AdapterLC)
ReadData$AdapterLength <- ReadData$AdapterRC - ReadData$AdapterLC +1

### Has to do with muliple adapter matches to a single read
write.table(ReadData[ReadData$AdapterLength >50 ,c("Acc","AdapterLC","AdapterRC")],
    file="adapterClip.txt",sep="\t",row.names=F,col.names=F,quote=F)
system("sfffile -i adapterClip.txt -tr adapterClip.txt -o adapterClip.sff combined.sff")
system("sff_extract -c adapterClip.sff")

#@    661982 reads written into the SFF file.

system("cross_match adapterClip.fasta ../screen.fa -minmatch 15 -minscore 14 -screen -tags > cross_match2.out")
system("grep \"ALIGNMENT\" cross_match2.out | replace ' C ' ' C_' --  > cm_alignment2.out")
system("wc -l cm_alignment2.out")
#@ 1 cm_alignment2.out

## all reads with multiple tags get 
cm_out2 <- read.table("cm_alignment2.out",as.is=TRUE)
ReadData$AdapterRC[match(cm_out2$V6,ReadData$Acc)] <- ReadData$AdapterLC[match(cm_out2$V6,ReadData$Acc)]
ReadData$AdapterLength <- ReadData$AdapterRC - ReadData$AdapterLC +1

### Has to do with muliple adapter matches to a single read
write.table(ReadData[ReadData$AdapterLength >50 ,c("Acc","AdapterLC","AdapterRC")],
    file="adapterClip.txt",sep="\t",row.names=F,col.names=F,quote=F)
system("sfffile -i adapterClip.txt -tr adapterClip.txt -o adapterClip.sff combined.sff")
system("sff_extract -c adapterClip.sff")

#@    661982 reads written into the SFF file.

system("cross_match adapterClip.fasta ../screen.fa -minmatch 15 -minscore 14 -screen -tags > cross_match3.out")
system("grep \"ALIGNMENT\" cross_match3.out | replace ' C ' ' C_' --  > cm_alignment3.out")
system("wc -l cm_alignment2.out")

#@ 0 cm_alignment2.out


fa.adapter <- subseq(sread(fq),ReadData$AdapterLC,ReadData$AdapterRC)
fa.adapter <- fa.adapter[match(ReadData$Acc[ReadData$AdapterLength > 50],id(fq))]
names(fa.adapter) <- ReadData$Acc[ReadData$AdapterLength > 50]

ReadData$AdapterNs[ReadData$AdapterLength>50] <- alphabetFrequency(fa.adapter)[,"N"]

## check for poor regions with lucy
system("lucy -minimum 50 -output adapterClip_lucy.fasta adapterClip_lucy.fasta.qual -error 0.002 0.002 adapterClip.fasta  adapterClip.fasta.qual")

system("lucy2tab.pl -p n -i adapterClip_lucy.fasta -o lucy_clip.txt")


lucy <- read.table("lucy_clip.txt",as.is=T)

ReadData$lucyLC <- ReadData$AdapterLC
ReadData$lucyRC <- ReadData$AdapterRC
ReadData$lucyRC[match(lucy[,1],ReadData$Acc)] <- ReadData$AdapterLC[match(lucy[,1],ReadData$Acc)] + lucy[,3] -1
ReadData$lucyLC[match(lucy[,1],ReadData$Acc)] <- ReadData$AdapterLC[match(lucy[,1],ReadData$Acc)] + lucy[,2] -1
ReadData$lucyLength <- ReadData$lucyRC - ReadData$lucyLC +1
ReadData$keepLucy <- FALSE
ReadData$keepLucy[match(lucy[,1],ReadData$Acc)] <- TRUE


ReadData$lucyNs[ReadData$keepLucy] <- alphabetFrequency(fa2)[,"N"]

write.table(ReadData,file="ReadInfo.txt",sep="\t",row.names=F,col.names=T,quote=F)
#write.table(ReadData[ReadData$keepLucy ,c("Acc","lucyLC","lucyRC")],
#    file="lucyClip.txt",sep="\t",row.names=F,col.names=F,quote=F)
#system("sfffile -i lucyClip.txt -tr lucyClip.txt -o lucyClip.sff combined.sff")
#system("sff_extract -c lucyClip.sff")

d <- density(ReadData$RawLength)
d2 <- density(ReadData$RocheLength)
d3 <- density(ReadData$AdapterLength)
d4 <- density(ReadData$lucyLength)

plot(d)
lines(d2,col="red")
lines(d3,col="green")
lines(d4,col="orange")

## get unique sequences
fa.lucy <- subseq(sread(fq),ReadData$lucyLC,ReadData$lucyRC)
fa.lucy <- fa.lucy[match(ReadData$Acc[ReadData$keepLucy],id(fq))]
names(fa.lucy) <- ReadData$Acc[ReadData$keepLucy]

fa.lucy <- sort(fa.lucy)
lucy.unique <- length(unique(fa.lucy))
UniqueID <- rep(paste("UniqueRead",seq.int(lucy.unique),sep="."),times=diff(c(which(!duplicated(fa.lucy)),length(fa.lucy)+1)))
ReadData$LucyUnique[match(names(fa.lucy),ReadData$Acc)] <- UniqueID

fa.adapter <- subseq(sread(fq),ReadData$AdapterLC,ReadData$AdapterRC)
fa.adapter <- fa.adapter[match(ReadData$Acc[ReadData$AdapterLength > 50],id(fq))]
names(fa.adapter) <- ReadData$Acc[ReadData$AdapterLength > 50]

fa.adapter <- sort(fa.adapter)
adapter.unique <- length(unique(fa.adapter))
UniqueID <- rep(paste("UniqueRead",seq.int(adapter.unique),sep="."),times=diff(c(which(!duplicated(fa.adapter)),length(fa.adapter)+1)))
ReadData$AdapterUnique[match(names(fa.adapter),ReadData$Acc)] <- UniqueID

write.table(ReadData,file="ReadInfo.txt",sep="\t",row.names=F,col.names=T,quote=F)

write.table(ReadData[(!duplicated(ReadData$AdapterUnique) & !is.na(ReadData$AdapterUnique)) ,c("Acc","AdapterLC","AdapterRC")],
    file="AdapterClipUnique.txt",sep="\t",row.names=F,col.names=F,quote=F)
system("sfffile -i AdapterClipUnique.txt -tr AdapterClipUnique.txt -o AdapterClipUnique.sff combined.sff")
system("sff_extract -c AdapterClipUnique.sff")

write.table(ReadData[(!duplicated(ReadData$LucyUnique) & !is.na(ReadData$LucyUnique)) ,c("Acc","lucyLC","lucyRC")],
    file="lucyClipUnique.txt",sep="\t",row.names=F,col.names=F,quote=F)
system("sfffile -i lucyClipUnique.txt -tr lucyClipUnique.txt -o lucyClipUnique.sff combined.sff")
system("sff_extract -c lucyClipUnique.sff")


table(ReadData[ReadData$keepLucy,"Tag"],ReadData[ReadData$keepLucy,"Region"])
                         





















#back up to main folder

#make links for mira
#ln -s SFF/combined.fasta.screen  T_gondaii_comb_in.454.fasta
#ln -s SFF/combined.fasta.qual T_gondaii_comb_in.454.fasta.qual
#ln -s SFF/combined.xml T_gondaii_comb_traceinfo_in.454.xml

#mira -GE:not=8 -project=T_gondaii_comb -job=denovo,genome,draft,454 454_SETTINGS -CL:qc=no -CL:mbc > mire_comb.out

### RH
cross_match RH.fasta screen.fa -minmatch 15 -minscore 14 -screen -tags > cross_match_RH.out

grep "ALIGNMENT" cross_match_RH.out | replace ' C ' ' C_' --  > cm_RH_alignment.out

#back up to main folder

#make links for mira
ln -s SFF/RH.fasta.screen  T_gondaii_RH_in.454.fasta
ln -s SFF/RH.fasta.qual T_gondaii_RH_in.454.fasta.qual
ln -s SFF/RH.xml T_gondaii_RH_traceinfo_in.454.xml

mira -GE:not=8 -project=T_gondaii_RH -job=denovo,genome,draft,454 454_SETTINGS -CL:qc=no -CL:mbc > mira_RH.out

### RH
cross_match RH.fasta screen.fa -minmatch 15 -minscore 14 -screen -tags > cross_match_RH.out

grep "ALIGNMENT" cross_match_RH.out | replace ' C ' ' C_' --  > cm_RH_alignment.out

#back up to main folder

#make links for mira
ln -s SFF/RH.fasta.screen  T_gondaii_RH_in.454.fasta
ln -s SFF/RH.fasta.qual T_gondaii_RH_in.454.fasta.qual
ln -s SFF/RH.xml T_gondaii_RH_traceinfo_in.454.xml

mira -GE:not=8 -project=T_gondaii_RH -job=denovo,genome,draft,454 454_SETTINGS -CL:qc=no -CL:mbc > mira_RH.out





