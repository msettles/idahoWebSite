#!/bin/env python
#This python script requires Biopython 1.51 or later
# Description:
#
# Author: Matt Settles <msettles@uidaho.edu>
# Last Edited: Feb 12, 2012
#
# Assumptions:
# for paired end data:
#   Reads are in 2 fastq files and read ids are the same
#   (i.e. read id does not end with /1 or /2 as is common for paired end data)

from optparse import OptionParser
from Bio import SeqIO
import itertools
import sys
usage = "usage: %prog [options] file_1.fastq file_2.fastq"
parser = OptionParser(usage=usage)
parser.add_option("-o", "--outfile",
                  action="store", type="string", dest="file_out",
                  help="write output to FILE", metavar="FILE")
parser.add_option("-f", "--format",
                  action="store", type="string", dest="format", default="fastq",
                  help="input file format (fastq,fastq-illumina, or fasta)")
parser.add_option("-q", "--min-quality",
                  action="store", type="int", dest="quality", default=0,
                  help="minimum quality with which to keep the set of reads")

# for command line testin
#option_args= ["-f", "fastq", "test_1.fq", "test_2.fq"]
#(options, args) = parser.parse_args(option_args)

(options, args) = parser.parse_args()

if len(args) != 2:
    parser.error("incorrect number of arguments")

format = options.format

file_f = args[0]
file_r = args[1]

records_f = SeqIO.parse(open(file_f,"rU"), format)
records_r = SeqIO.parse(open(file_r,"rU"), format)

if options.file_out is None:
    handle = sys.stdout
    options.file_out = "stdout"
else:
    handle = open(options.file_out, "w")

quality = options.quality

def interleave (iter1,iter2):
    for (forward, reverse) in itertools.izip(iter1,iter2):
        assert forward.id == reverse.id
        key = forward.letter_annotations.keys()[0] ## get key for quality
        qfr = forward.letter_annotations[key] + reverse.letter_annotations[key]
        mq = sum(qfr)/len(qfr)
        if mq >= quality:
            forward.id += "/1"
            reverse.id += "/2"
            yield forward
            yield reverse

count = SeqIO.write(interleave(records_f, records_r), handle, format)

handle.close()
print >> sys.stderr, "%i records written to %s" % (count, options.file_out)


